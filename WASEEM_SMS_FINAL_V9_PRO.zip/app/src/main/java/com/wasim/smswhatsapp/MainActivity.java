package com.wasim.smswhatsapp;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.database.ContentObserver;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.text.*;
import android.view.*;
import android.widget.*;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int REQ=77;
    private static final String PREF="waseem";
    private static final String CHANNEL="waseem_sms_alerts";
    private final ArrayList<SmsItem> sms=new ArrayList<>();
    private final ArrayList<ContactItem> contacts=new ArrayList<>();
    private final HashMap<String,String> contactNameCache=new HashMap<>();
    private boolean loading=false;
    private LinearLayout list;
    private TextView status, counter, statTotal, statToday, statContacts;
    private EditText search;
    private Spinner filter;
    private int tab=0;
    private long from=0,to=Long.MAX_VALUE;
    private String country="967", firstLine="اشعار من تموينات الخير";
    private ContentObserver observer;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private boolean waiting=false;
    private long pendingId=-1;
    private final HashSet<Long> selectedIds=new HashSet<>();
    private final ArrayList<SmsItem> bulkQueue=new ArrayList<>();
    private int bulkIndex=0;
    private boolean bulkMode=false;
    private final int navy=Color.rgb(9,18,32), navy2=Color.rgb(18,31,52), green=Color.rgb(20,166,92), greenDark=Color.rgb(13,123,67), bg=Color.rgb(244,247,250), ink=Color.rgb(20,32,51), muted=Color.rgb(100,113,130), red=Color.rgb(198,55,55), amber=Color.rgb(184,126,20);

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(navy); getWindow().setNavigationBarColor(navy);
        country=getPreferences(0).getString("country","967");
        firstLine=getPreferences(0).getString("first_line","اشعار من تموينات الخير");
        buildUi(); requestPermissionsIfNeeded(); registerObserver(); loadSms();
    }
    @Override protected void onResume(){ super.onResume(); if(waiting){ waiting=false; handler.postDelayed(this::askConfirmation,500); } }
    @Override protected void onDestroy(){ if(observer!=null) getContentResolver().unregisterContentObserver(observer); super.onDestroy(); }

    private int d(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private TextView text(String s,float size,int color){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);v.setPadding(d(10),d(4),d(10),d(4));return v;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(13);b.setAllCaps(false);b.setMinHeight(0);b.setMinimumHeight(0);return b;}
    private GradientDrawable shape(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(d(radius));return g;}
    private LinearLayout.LayoutParams lp(int w,int h,int weight){return new LinearLayout.LayoutParams(w,h,weight);}
    private LinearLayout.LayoutParams bottom(int n){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,0,0,d(n));return p;}

    private void buildUi(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(bg);root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(d(12),d(8),d(8),d(8));header.setBackgroundColor(navy);
        ImageView icon=new ImageView(this);icon.setImageResource(R.drawable.ic_waseem);header.addView(icon,new LinearLayout.LayoutParams(d(48),d(48)));
        LinearLayout ht=new LinearLayout(this);ht.setOrientation(LinearLayout.VERTICAL);ht.setPadding(d(8),0,d(8),0);
        TextView title=text("WASEEM SMS",20,Color.WHITE);title.setTypeface(null,Typeface.BOLD);ht.addView(title,new LinearLayout.LayoutParams(-1,d(29)));
        TextView sub=text("SMART SMS  •  WHATSAPP",11,Color.rgb(172,226,198));ht.addView(sub,new LinearLayout.LayoutParams(-1,d(22)));header.addView(ht,lp(0,d(56),1));
        Button set=button("⚙");set.setTextSize(22);set.setTextColor(Color.WHITE);set.setBackgroundColor(navy);set.setOnClickListener(v->settingsDialog());header.addView(set,new LinearLayout.LayoutParams(d(52),d(56)));root.addView(header);

        LinearLayout hero=new LinearLayout(this);hero.setOrientation(LinearLayout.VERTICAL);hero.setPadding(d(18),d(16),d(18),d(16));hero.setBackgroundColor(navy2);
        TextView hh=text("إدارة رسائل العملاء بذكاء",20,Color.WHITE);hh.setTypeface(null,Typeface.BOLD);hero.addView(hh);
        TextView hs=text("قراءة • بحث • تحديد • إرسال جماعي إلى WhatsApp",12,Color.rgb(220,228,238));hero.addView(hs);root.addView(hero);

        LinearLayout stats=new LinearLayout(this);stats.setPadding(d(10),d(10),d(10),d(5));
        statTotal=statCard(stats,"إجمالي الرسائل","0",0);statToday=statCard(stats,"رسائل اليوم","0",1);statContacts=statCard(stats,"جهات الاتصال","0",2);root.addView(stats);

        LinearLayout tabs=new LinearLayout(this);tabs.setPadding(d(10),d(3),d(10),d(3));Button smsTab=button("▣  الرسائل");Button conTab=button("♙  جهات الاتصال");tabs.addView(smsTab,lp(0,d(46),1));tabs.addView(conTab,lp(0,d(46),1));root.addView(tabs);
        styleTab(smsTab,true);styleTab(conTab,false);
        smsTab.setOnClickListener(v->{tab=0;styleTab(smsTab,true);styleTab(conTab,false);loadSms();});
        conTab.setOnClickListener(v->{tab=1;styleTab(smsTab,false);styleTab(conTab,true);loadContacts();});

        LinearLayout searchRow=new LinearLayout(this);searchRow.setPadding(d(10),d(3),d(10),d(3));
        search=new EditText(this);search.setSingleLine(true);search.setTextSize(14);search.setHint("ابحث في الرسائل بالرقم أو الاسم أو النص");search.setPadding(d(14),0,d(14),0);search.setBackground(shape(Color.WHITE,14));searchRow.addView(search,lp(0,d(50),1));
        Button find=button("بحث");find.setTextColor(Color.WHITE);find.setTypeface(null,Typeface.BOLD);find.setBackground(shape(green,14));LinearLayout.LayoutParams fp=new LinearLayout.LayoutParams(d(72),d(50));fp.setMargins(d(7),0,0,0);searchRow.addView(find,fp);root.addView(searchRow);
        find.setOnClickListener(v->render());search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int a,int b,int c){}public void onTextChanged(CharSequence s,int a,int b,int c){render();}public void afterTextChanged(Editable e){}});

        LinearLayout filters=new LinearLayout(this);filters.setPadding(d(10),d(3),d(10),d(3));
        filter=new Spinner(this);String[] modes={"رسائل مرسلة اليوم","رسائل اليوم كلها","كل الرسائل المرسلة","كل الرسائل","أحدث 50 رسالة","تاريخ محدد","من تاريخ إلى تاريخ"};filter.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,modes));filters.addView(filter,lp(0,d(48),1));
        Button date=button("📅 التاريخ");date.setBackground(shape(Color.WHITE,12));LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(d(100),d(48));dp.setMargins(d(7),0,0,0);filters.addView(date,dp);root.addView(filters);
        filter.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){public void onItemSelected(AdapterView<?> p,View v,int pos,long id){if(pos==5)pickDate(false);else if(pos==6)pickDate(true);else{from=0;to=Long.MAX_VALUE;render();}}public void onNothingSelected(AdapterView<?> p){}});
        date.setOnClickListener(v->{int p=filter.getSelectedItemPosition();if(p==5)pickDate(false);else if(p==6)pickDate(true);else Toast.makeText(this,"اختر نوع التاريخ أولًا",Toast.LENGTH_SHORT).show();});

        LinearLayout actions=new LinearLayout(this);actions.setPadding(d(10),d(3),d(10),d(3));Button refresh=button("↻  تحديث");Button all=button("كل الرسائل");refresh.setBackground(shape(Color.WHITE,12));all.setBackground(shape(Color.WHITE,12));actions.addView(refresh,lp(0,d(46),1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,d(46),1);ap.setMargins(d(7),0,0,0);actions.addView(all,ap);root.addView(actions);
        refresh.setOnClickListener(v->{if(tab==0)loadSms();else loadContacts();});all.setOnClickListener(v->{tab=0;filter.setSelection(3);loadSms();});
        status=text("جاهز",12,muted);counter=text("",12,muted);root.addView(status);root.addView(counter);
        LinearLayout bulk=new LinearLayout(this);bulk.setPadding(d(10),d(3),d(10),d(3));
        Button sendBulk=button("📤  إرسال جماعي");sendBulk.setTextColor(Color.WHITE);sendBulk.setTypeface(null,Typeface.BOLD);sendBulk.setBackground(shape(greenDark,12));
        Button selectAll=button("تحديد الكل");selectAll.setBackground(shape(Color.WHITE,12));
        Button clearSel=button("إلغاء التحديد");clearSel.setBackground(shape(Color.WHITE,12));
        bulk.addView(sendBulk,lp(0,d(48),2));LinearLayout.LayoutParams bp=lp(0,d(48),1);bp.setMargins(d(6),0,0,0);bulk.addView(selectAll,bp);LinearLayout.LayoutParams bcp=lp(0,d(48),1);bcp.setMargins(d(6),0,0,0);bulk.addView(clearSel,bcp);root.addView(bulk);
        sendBulk.setOnClickListener(v->startBulkSend());
        selectAll.setOnClickListener(v->{selectedIds.clear();String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);int selected=filter==null?3:filter.getSelectedItemPosition();int n=0;for(SmsItem x:sms){if(acceptDate(x.date,selected))if(!((selected==0||selected==2)&&x.type!=Telephony.Sms.MESSAGE_TYPE_SENT))if(q.isEmpty()||(x.address+" "+x.name+" "+x.body).toLowerCase(Locale.ROOT).contains(q)){selectedIds.add(x.id);n++;if(selected==4&&n>=50)break;}}render();Toast.makeText(this,"تم تحديد "+selectedIds.size()+" رسالة",Toast.LENGTH_SHORT).show();});
        clearSel.setOnClickListener(v->{selectedIds.clear();render();});
        ScrollView sv=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);list.setPadding(d(10),d(5),d(10),d(28));sv.addView(list);root.addView(sv,lp(-1,0,1));
        setContentView(root);
    }
    private TextView statCard(LinearLayout row,String label,String value,int which){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setGravity(Gravity.CENTER);c.setPadding(d(7),d(7),d(7),d(7));c.setBackground(shape(Color.WHITE,15));TextView a=text(value,19,greenDark);a.setTypeface(null,Typeface.BOLD);a.setGravity(Gravity.CENTER);TextView b=text(label,10,muted);b.setGravity(Gravity.CENTER);c.addView(a,new LinearLayout.LayoutParams(-1,d(29)));c.addView(b,new LinearLayout.LayoutParams(-1,d(22)));LinearLayout.LayoutParams p=lp(0,d(66),1);if(which>0)p.setMargins(d(6),0,0,0);row.addView(c,p);return a;}
    private void styleTab(Button b,boolean active){b.setTextColor(active?Color.WHITE:muted);b.setTypeface(null,Typeface.BOLD);b.setBackground(shape(active?green:Color.WHITE,12));}
    private boolean has(String p){return ContextCompat.checkSelfPermission(this,p)==PackageManager.PERMISSION_GRANTED;}
    private void requestPermissionsIfNeeded(){ArrayList<String> p=new ArrayList<>();if(!has(Manifest.permission.READ_SMS))p.add(Manifest.permission.READ_SMS);if(!has(Manifest.permission.RECEIVE_SMS))p.add(Manifest.permission.RECEIVE_SMS);if(!has(Manifest.permission.READ_CONTACTS))p.add(Manifest.permission.READ_CONTACTS);if(Build.VERSION.SDK_INT>=33&&!has(Manifest.permission.POST_NOTIFICATIONS))p.add(Manifest.permission.POST_NOTIFICATIONS);if(!p.isEmpty())requestPermissions(p.toArray(new String[0]),REQ);}
    @Override public void onRequestPermissionsResult(int r,String[] p,int[] g){super.onRequestPermissionsResult(r,p,g);loadSms();}
    private void registerObserver(){observer=new ContentObserver(handler){@Override public void onChange(boolean self){handler.removeCallbacksAndMessages(null);handler.postDelayed(()->{if(tab==0)loadSms();},400);}};try{getContentResolver().registerContentObserver(Telephony.Sms.CONTENT_URI,true,observer);}catch(Exception ignored){}}

    private void loadSms(){
        if(!has(Manifest.permission.READ_SMS)){status.setText("⚠ يحتاج التطبيق إلى إذن قراءة SMS");return;}
        if(loading){Toast.makeText(this,"جاري تحديث البيانات…",Toast.LENGTH_SHORT).show();return;}
        loading=true; status.setText("جاري تحميل الرسائل…");
        new Thread(()->{
            ArrayList<SmsItem> tmp=new ArrayList<>(); Cursor c=null;
            try{
                loadContactCache();
                c=getContentResolver().query(Telephony.Sms.CONTENT_URI,
                    new String[]{Telephony.Sms._ID,Telephony.Sms.ADDRESS,Telephony.Sms.BODY,Telephony.Sms.DATE,Telephony.Sms.TYPE},
                    null,null,Telephony.Sms.DATE+" DESC");
                if(c!=null) while(c.moveToNext()){
                    String n=c.getString(1); String body=c.getString(2);
                    tmp.add(new SmsItem(c.getLong(0),n,body,c.getLong(3),c.getInt(4),findCachedName(n)));
                }
            }catch(Exception e){String m=e.getMessage()==null?e.toString():e.getMessage();runOnUiThread(()->status.setText("تعذر تحميل الرسائل: "+m));}
            finally{if(c!=null)c.close();}
            runOnUiThread(()->{loading=false;sms.clear();sms.addAll(tmp);status.setText("✓ تم تحميل "+sms.size()+" رسالة");updateStats();render();});
        }).start();
    }
    private void loadContactCache(){
        contactNameCache.clear();
        if(!has(Manifest.permission.READ_CONTACTS)) return;
        Cursor c=null; try{
            c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},
                null,null,null);
            if(c!=null) while(c.moveToNext()){
                String name=c.getString(0), num=c.getString(1); String key=digits(num);
                if(key.length()>0 && name!=null && !name.isEmpty()) contactNameCache.put(key,name);
            }
        }catch(Exception ignored){} finally{if(c!=null)c.close();}
    }
    private String digits(String n){return n==null?"":n.replaceAll("[^0-9]","");}
    private String findCachedName(String n){
        String k=digits(n); if(k.isEmpty())return "";
        String v=contactNameCache.get(k); if(v!=null)return v;
        if(k.startsWith("967")&&k.length()>3){v=contactNameCache.get(k.substring(3));if(v!=null)return v;}
        if(k.startsWith("0")){v=contactNameCache.get("967"+k.substring(1));if(v!=null)return v;}
        return "";
    }

    private void loadContacts(){
        if(!has(Manifest.permission.READ_CONTACTS)){requestPermissions(new String[]{Manifest.permission.READ_CONTACTS},REQ);return;}
        if(loading){Toast.makeText(this,"جاري تحديث البيانات…",Toast.LENGTH_SHORT).show();return;}
        loading=true;status.setText("جاري تحميل جهات الاتصال…");
        new Thread(()->{ArrayList<ContactItem> tmp=new ArrayList<>();HashSet<String> seen=new HashSet<>();Cursor c=null;
            try{c=getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},null,null,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" COLLATE LOCALIZED ASC");
                if(c!=null)while(c.moveToNext()){String n=c.getString(0),p=c.getString(1);if(seen.add(n+"|"+p))tmp.add(new ContactItem(n,p));}
            }catch(Exception e){String m=e.getMessage()==null?e.toString():e.getMessage();runOnUiThread(()->status.setText("تعذر تحميل جهات الاتصال: "+m));}
            finally{if(c!=null)c.close();}
            runOnUiThread(()->{loading=false;contacts.clear();contacts.addAll(tmp);loadContactCache();status.setText("✓ تم تحميل "+contacts.size()+" جهة اتصال");updateStats();render();});
        }).start();
    }

    private void updateStats(){if(statTotal!=null)statTotal.setText(String.valueOf(sms.size()));int today=0;for(SmsItem x:sms)if(sameDay(x.date,System.currentTimeMillis()))today++;if(statToday!=null)statToday.setText(String.valueOf(today));if(statContacts!=null)statContacts.setText(String.valueOf(contacts.size()));}
    private void render(){if(list==null)return;list.removeAllViews();String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);if(tab==1){int n=0;for(ContactItem x:contacts)if(q.isEmpty()||(x.name+" "+x.number).toLowerCase(Locale.ROOT).contains(q)){addContact(x);n++;}counter.setText("جهات الاتصال المطابقة: "+n);if(n==0)empty("لا توجد جهة اتصال مطابقة");return;}int n=0,selected=filter==null?3:filter.getSelectedItemPosition();for(SmsItem x:sms){if(!acceptDate(x.date,selected))continue;if((selected==0||selected==2)&&x.type!=Telephony.Sms.MESSAGE_TYPE_SENT)continue;if(q.isEmpty()||(x.address+" "+x.name+" "+x.body).toLowerCase(Locale.ROOT).contains(q)){if(n<200)addSms(x);n++;if(selected==4&&n>=50)break;}}counter.setText("النتائج: "+n+"  •  إجمالي الرسائل: "+sms.size()+(n>200?"  •  يتم عرض أول 200":""));if(n==0)empty("لا توجد رسائل مطابقة");}
    private boolean acceptDate(long t,int m){if(m==0||m==1)return sameDay(t,System.currentTimeMillis());if(m==5||m==6)return t>=from&&t<=to;return true;}
    private boolean sameDay(long a,long b){Calendar x=Calendar.getInstance(),y=Calendar.getInstance();x.setTimeInMillis(a);y.setTimeInMillis(b);return x.get(Calendar.YEAR)==y.get(Calendar.YEAR)&&x.get(Calendar.DAY_OF_YEAR)==y.get(Calendar.DAY_OF_YEAR);}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(d(14),d(12),d(14),d(12));c.setBackground(shape(Color.WHITE,17));return c;}
    private void addSms(SmsItem x){LinearLayout c=card();
        LinearLayout titleRow=new LinearLayout(this);titleRow.setGravity(Gravity.CENTER_VERTICAL);
        CheckBox cb=new CheckBox(this);cb.setChecked(selectedIds.contains(x.id));cb.setText("تحديد للإرسال الجماعي");cb.setTextSize(12);cb.setTextColor(muted);cb.setOnCheckedChangeListener((b,checked)->{if(checked)selectedIds.add(x.id);else selectedIds.remove(x.id);counter.setText("المحدد للإرسال الجماعي: "+selectedIds.size());});titleRow.addView(cb,new LinearLayout.LayoutParams(-1,d(42)));c.addView(titleRow);
        TextView top=text(new SimpleDateFormat("yyyy/MM/dd  •  HH:mm",Locale.US).format(new Date(x.date))+"   |   "+(x.type==Telephony.Sms.MESSAGE_TYPE_SENT?"مرسلة":"واردة"),11,muted);c.addView(top);TextView name=text(x.name.isEmpty()?"بدون اسم":"👤  "+x.name,15,ink);name.setTypeface(null,Typeface.BOLD);c.addView(name);c.addView(text("📱  "+x.address,13,muted));TextView body=text(x.body==null?"":x.body,15,ink);body.setGravity(Gravity.RIGHT|Gravity.TOP);body.setBackground(shape(Color.rgb(247,249,252),12));body.setPadding(d(12),d(12),d(12),d(12));c.addView(body,new LinearLayout.LayoutParams(-1,d(112)));
        TextView st=text(statusLabel(x.id),12,statusColor(x.id));st.setTypeface(null,Typeface.BOLD);c.addView(st);
        LinearLayout row=new LinearLayout(this);Button wa=button("💬  فتح WhatsApp");wa.setTextColor(Color.WHITE);wa.setTypeface(null,Typeface.BOLD);wa.setBackground(shape(green,12));wa.setOnClickListener(v->openWhatsApp(x));Button copy=button("نسخ");copy.setBackground(shape(Color.rgb(235,239,244),12));copy.setOnClickListener(v->{android.content.ClipboardManager cm=(android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);cm.setPrimaryClip(android.content.ClipData.newPlainText("SMS",x.body));Toast.makeText(this,"تم نسخ نص الرسالة كاملًا",Toast.LENGTH_SHORT).show();});row.addView(wa,lp(0,d(48),2));LinearLayout.LayoutParams cp=lp(0,d(48),1);cp.setMargins(d(7),0,0,0);row.addView(copy,cp);c.addView(row);list.addView(c,bottom(10));}
    private void addContact(ContactItem x){LinearLayout c=card();TextView n=text("👤  "+x.name,17,ink);n.setTypeface(null,Typeface.BOLD);c.addView(n);c.addView(text("📱  "+x.number,14,muted));Button wa=button("💬  فتح WhatsApp");wa.setTextColor(Color.WHITE);wa.setBackground(shape(green,12));wa.setOnClickListener(v->openWhatsAppContact(x.number));c.addView(wa,new LinearLayout.LayoutParams(-1,d(48)));list.addView(c,bottom(10));}
    private void empty(String s){TextView e=text("◎\n"+s,15,muted);e.setGravity(Gravity.CENTER);list.addView(e,new LinearLayout.LayoutParams(-1,d(150)));}

    private String norm(String raw){String s=raw==null?"":raw.trim().replaceAll("[^0-9+]","");if(s.startsWith("00"))s=s.substring(2);if(s.startsWith("+"))s=s.substring(1);if(s.startsWith(country))return s;if(s.startsWith("0"))s=s.substring(1);if(s.length()==9)return country+s;return s;}
    private void openWhatsAppContact(String raw){String p=norm(raw);if(p.length()<7){show("رقم غير صالح","الرقم: "+raw);return;}String url="https://wa.me/"+p+"?text="+Uri.encode("");Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));try{i.setPackage("com.whatsapp");startActivity(i);return;}catch(Exception ignored){}try{i.setPackage("com.whatsapp.w4b");startActivity(i);return;}catch(Exception ignored){}show("تعذر فتح WhatsApp","تأكد من تثبيت WhatsApp أو WhatsApp Business.");}
    private void openWhatsApp(SmsItem x){String p=norm(x.address);if(p.length()<7){setState(x.id,3);render();show("رقم غير صالح","الرقم الظاهر في SMS: "+x.address);return;}String url="https://wa.me/"+p+"?text="+Uri.encode(x.body==null?"":x.body);Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));boolean ok=false;try{i.setPackage("com.whatsapp");startActivity(i);ok=true;}catch(Exception ignored){}if(!ok)try{i.setPackage("com.whatsapp.w4b");startActivity(i);ok=true;}catch(Exception ignored){}if(ok){setState(x.id,1);pendingId=x.id;waiting=true;render();}else{setState(x.id,3);render();show("تعذر فتح WhatsApp","تأكد من تثبيت WhatsApp أو WhatsApp Business.");}}
    private void askConfirmation(){if(pendingId<0)return;new AlertDialog.Builder(this).setTitle(bulkMode?"إرسال جماعي — حالة الرسالة":"حالة رسالة WhatsApp").setMessage(bulkMode?"بعد فتح WhatsApp، اضغط «إرسال»، ثم ارجع للتطبيق للانتقال للرسالة التالية.\n\nهل تم الإرسال؟":"بعد فتح WhatsApp، هل ضغطت زر «إرسال»؟").setPositiveButton("✓ تم الإرسال",(d,w)->{setState(pendingId,2);pendingId=-1;render();if(bulkMode)continueBulk();}).setNegativeButton("⏳ لا، ما زالت معلقة",(d,w)->{setState(pendingId,0);pendingId=-1;render();if(bulkMode)continueBulk();}).setCancelable(false).show();}
    private void startBulkSend(){
        if(bulkMode){Toast.makeText(this,"الإرسال الجماعي قيد التنفيذ",Toast.LENGTH_SHORT).show();return;}
        bulkQueue.clear();String q=search==null?"":search.getText().toString().trim().toLowerCase(Locale.ROOT);int selected=filter==null?3:filter.getSelectedItemPosition();
        for(SmsItem x:sms){if(!selectedIds.contains(x.id))continue;if(!acceptDate(x.date,selected))continue;if((selected==0||selected==2)&&x.type!=Telephony.Sms.MESSAGE_TYPE_SENT)continue;if(!q.isEmpty()&&!(x.address+" "+x.name+" "+x.body).toLowerCase(Locale.ROOT).contains(q))continue;bulkQueue.add(x);}
        if(bulkQueue.isEmpty()){show("الإرسال الجماعي","حدد رسالة واحدة على الأقل من الرسائل الظاهرة.");return;}
        bulkMode=true;bulkIndex=0;Toast.makeText(this,"سيتم فتح "+bulkQueue.size()+" رسالة بالتتابع. اضغط إرسال في WhatsApp ثم ارجع للتطبيق.",Toast.LENGTH_LONG).show();continueBulk();
    }
    private void continueBulk(){if(!bulkMode)return;if(bulkIndex>=bulkQueue.size()){bulkMode=false;bulkQueue.clear();selectedIds.clear();render();show("اكتمل الإرسال الجماعي","تمت معالجة جميع الرسائل المحددة. راجع حالة كل رسالة في القائمة.");return;}SmsItem x=bulkQueue.get(bulkIndex++);pendingId=x.id;openWhatsAppForBulk(x);}
    private void openWhatsAppForBulk(SmsItem x){String p=norm(x.address);if(p.length()<7){setState(x.id,3);render();Toast.makeText(this,"رقم غير صالح للرسالة التالية",Toast.LENGTH_SHORT).show();continueBulk();return;}String url="https://wa.me/"+p+"?text="+Uri.encode(x.body==null?"":x.body);Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(url));boolean ok=false;try{i.setPackage("com.whatsapp");startActivity(i);ok=true;}catch(Exception ignored){}if(!ok)try{i.setPackage("com.whatsapp.w4b");startActivity(i);ok=true;}catch(Exception ignored){}if(ok){setState(x.id,1);waiting=true;render();}else{setState(x.id,3);render();show("تعذر فتح WhatsApp","تأكد من تثبيت WhatsApp أو WhatsApp Business. سيتم الانتقال للرسالة التالية.");continueBulk();}}
    private String statusLabel(long id){int s=getState(id);if(s==2)return "✓ تم الإرسال — تم تأكيده";if(s==1)return "⏳ مفتوح في WhatsApp — بانتظار الإرسال";if(s==3)return "✕ تعذر فتح WhatsApp";return "⏳ معلّقة — لم يتم الإرسال بعد";}
    private int statusColor(long id){int s=getState(id);return s==2?green:(s==3?red:amber);}
    private int getState(long id){return getPreferences(0).getInt("wa_"+id,0);} private void setState(long id,int s){getPreferences(0).edit().putInt("wa_"+id,s).apply();}

    private void pickDate(boolean range){Calendar cal=Calendar.getInstance();DatePickerDialog dlg=new DatePickerDialog(this,(v,y,m,day)->{Calendar c=Calendar.getInstance();c.set(y,m,day,0,0,0);c.set(Calendar.MILLISECOND,0);from=c.getTimeInMillis();if(range){pickEndDate();}else{c.add(Calendar.DAY_OF_MONTH,1);to=c.getTimeInMillis()-1;render();}},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));dlg.setTitle(range?"اختر تاريخ البداية":"اختر التاريخ");dlg.show();}
    private void pickEndDate(){Calendar cal=Calendar.getInstance();DatePickerDialog dlg=new DatePickerDialog(this,(v,y,m,day)->{Calendar c=Calendar.getInstance();c.set(y,m,day,23,59,59);c.set(Calendar.MILLISECOND,999);to=c.getTimeInMillis();if(to<from)Toast.makeText(this,"تاريخ النهاية يجب أن يكون بعد البداية",Toast.LENGTH_SHORT).show();else render();},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));dlg.setTitle("اختر تاريخ النهاية");dlg.show();}

    private void settingsDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(d(20),0,d(20),0);
        TextView info=text("تحكم كامل في طريقة التعرف على الإشعارات وتحويل الرسائل إلى WhatsApp.",12,muted);info.setGravity(Gravity.RIGHT|Gravity.TOP);box.addView(info,new LinearLayout.LayoutParams(-1,d(55)));
        EditText first=new EditText(this);first.setText(firstLine);first.setHint("أول جملة من الإشعار");first.setTextSize(15);first.setSingleLine(true);first.setBackground(shape(Color.rgb(247,249,252),12));first.setPadding(d(12),0,d(12),0);box.addView(first,new LinearLayout.LayoutParams(-1,d(56)));
        TextView ex=text("مثال: «اشعار من تموينات الخير». يجب أن يبدأ نص SMS بهذه العبارة حتى يصدر تنبيه.",11,muted);ex.setGravity(Gravity.RIGHT|Gravity.TOP);box.addView(ex,new LinearLayout.LayoutParams(-1,d(48)));
        EditText cc=new EditText(this);cc.setText(country);cc.setHint("رمز الدولة");cc.setInputType(2);cc.setSingleLine(true);cc.setBackground(shape(Color.rgb(247,249,252),12));cc.setPadding(d(12),0,d(12),0);box.addView(cc,new LinearLayout.LayoutParams(-1,d(56)));
        TextView cx=text("اليمن: 77xxxxxxx  →  96777xxxxxxx",11,muted);cx.setGravity(Gravity.RIGHT);box.addView(cx,new LinearLayout.LayoutParams(-1,d(32)));
        CheckBox notify=new CheckBox(this);notify.setText("تفعيل إشعارات الرسائل المطابقة");notify.setTextSize(14);notify.setChecked(getPreferences(0).getBoolean("notify",true));box.addView(notify,new LinearLayout.LayoutParams(-1,d(50)));
        new AlertDialog.Builder(this).setTitle("⚙ إعدادات WASEEM SMS").setView(box).setNeutralButton("🔔 اختبار الإشعار",(d,w)->testNotification()).setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{String c=cc.getText().toString().replaceAll("[^0-9]","");country=c.isEmpty()?"967":c;firstLine=first.getText().toString().trim();getPreferences(0).edit().putString("country",country).putString("first_line",firstLine).putBoolean("notify",notify.isChecked()).apply();Toast.makeText(this,"✓ تم حفظ الإعدادات",Toast.LENGTH_SHORT).show();}).show();
    }
    private void testNotification(){createChannel();if(Build.VERSION.SDK_INT>=33&&!has(Manifest.permission.POST_NOTIFICATIONS)){requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},REQ);return;}NotificationManagerCompat.from(this).notify(9001,new NotificationCompat.Builder(this,CHANNEL).setSmallIcon(R.drawable.ic_waseem).setContentTitle("WASEEM SMS").setContentText("اختبار الإشعار — الإعدادات تعمل بنجاح").setAutoCancel(true).build());Toast.makeText(this,"تم إرسال إشعار الاختبار",Toast.LENGTH_SHORT).show();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);nm.createNotificationChannel(new NotificationChannel(CHANNEL,"تنبيهات WASEEM SMS",NotificationManager.IMPORTANCE_HIGH));}}
    private void show(String a,String b){new AlertDialog.Builder(this).setTitle(a).setMessage(b).setPositiveButton("موافق",null).show();}
}
