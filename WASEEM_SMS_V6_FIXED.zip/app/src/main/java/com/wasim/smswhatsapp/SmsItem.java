package com.wasim.smswhatsapp;
public class SmsItem {
 public long id,date; public String address,body,name; public int type;
 public SmsItem(long id,String address,String body,long date,int type,String name){this.id=id;this.address=address;this.body=body;this.date=date;this.type=type;this.name=name==null?"":name;}
}
