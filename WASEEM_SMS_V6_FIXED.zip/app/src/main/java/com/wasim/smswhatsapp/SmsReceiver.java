package com.wasim.smswhatsapp;

import android.app.*;
import android.content.*;
import android.os.Build;
import android.provider.Telephony;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class SmsReceiver extends BroadcastReceiver {
    private static final String CHANNEL="waseem_sms_alerts";
    @Override public void onReceive(Context c, Intent i){
        if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(i.getAction())) return;
        android.content.SharedPreferences sp=c.getSharedPreferences("waseem",0);
        if(!sp.getBoolean("notify",true)) return;
        String wanted=sp.getString("first_line","").trim();
        if(wanted.isEmpty()) return;
        android.telephony.SmsMessage[] msgs=Telephony.Sms.Intents.getMessagesFromIntent(i);
        if(msgs==null) return;
        for(android.telephony.SmsMessage m:msgs){
            if(m==null) continue;
            String body=m.getMessageBody()==null?"":m.getMessageBody().trim();
            if(body.regionMatches(true,0,wanted,0,wanted.length())){notify(c,m.getOriginatingAddress(),body);break;}
        }
    }
    private void notify(Context c,String number,String body){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"تنبيهات WASEEM SMS",NotificationManager.IMPORTANCE_HIGH));
        Intent open=new Intent(c,MainActivity.class);open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        String preview=body.length()>140?body.substring(0,140)+"…":body;
        NotificationCompat.Builder b=new NotificationCompat.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_waseem).setContentTitle("WASEEM SMS • رسالة مطابقة").setContentText(preview).setStyle(new NotificationCompat.BigTextStyle().bigText(body)).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(pi);
        NotificationManagerCompat.from(c).notify((int)(System.currentTimeMillis()%1000000),b.build());
    }
}
