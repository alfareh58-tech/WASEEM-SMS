package com.wasim.smswhatsapp;
public class ContactItem { public String name,number; public ContactItem(String n,String p){name=n;number=p;} }
