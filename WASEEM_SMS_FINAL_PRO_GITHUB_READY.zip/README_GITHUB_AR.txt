WASEEM SMS — النسخة النهائية الاحترافية

مهم: GitHub لا يفك ملف ZIP عند رفعه. يجب رفع محتويات المشروع مع مجلداته.

بعد رفع المشروع:
1) افتح Actions.
2) اختر Build WASEEM SMS APK.
3) اضغط Run workflow إذا لم يبدأ تلقائيًا.
4) بعد نجاح البناء افتح Artifacts.
5) نزّل WASEEM-SMS-APK ثم فك الضغط.
6) ثبّت app-debug.apk على هاتف Android.

هذه نسخة Android Native، وليست WebIntoApp.
