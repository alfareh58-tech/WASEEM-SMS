package com.wasim.smswhatsapp;
import android.content.*; import android.provider.Telephony;
public class SmsReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ if(Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(i.getAction())) c.getSharedPreferences("app",0).edit().putLong("last_sms",System.currentTimeMillis()).apply(); } }
